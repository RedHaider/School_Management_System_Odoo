# -*- coding: utf-8 -*-
#########################################
#     Developed by: TechTrioz
#########################################

from . import access_token, ir_model, stock_warehouse
from . import res_config_settings
from . import stock_location
