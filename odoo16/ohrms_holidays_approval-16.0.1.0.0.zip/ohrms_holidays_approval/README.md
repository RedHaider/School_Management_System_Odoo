Open HRMS Leave Multi-Level Approval v16
========================================
Supporting Addon for Open HRMS, Allows You To Create Leave Requests with multi level approvals.

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Technical Notes
---------------

Here you need to activate Multiple level approval in leave types
* Add list of validators in corresponding leave types

Contacts
--------
Info - info@cybrosys.com

Hajaj Roshan  - hajaj@cybrosys.in
Version 15 : Mily Shajan @ Cybrosys

Website:
-------
https://www.openhrms.com

https://www.cybrosys.com
