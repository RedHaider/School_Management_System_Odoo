# techtrioz-amcs
A complete ERP system for a garments industry.
