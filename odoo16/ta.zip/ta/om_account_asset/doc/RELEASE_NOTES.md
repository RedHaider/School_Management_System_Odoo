## Module <om_account_asset>

#### 24.10.2022
#### Version 16.0.1.1.0
##### ADD
- asset category

#### 22.07.2022
#### Version 16.0.1.0.0
##### ADD
- initial release
