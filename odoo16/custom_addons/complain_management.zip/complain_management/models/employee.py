# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError



class ComplainEmployee(models.Model):
    _name = "complain.employee"
    _description = "Complain Employee"

    name = fields.Char(string='First Name')
    age = fields.Integer(string="Age")
    code = fields.Integer(string="Code")
    complain = fields.Char(string="Complain")